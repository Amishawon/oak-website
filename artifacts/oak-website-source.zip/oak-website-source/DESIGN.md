# Oak visual system

Retain the supplied Oak logo, green #3aad5c, pink #ec1652, cream #f7f4ee, and bundled Poppins type. The public site uses generous spacing, rounded photography, green actions and responsive grids. The editor is an Operate surface: warm off-white canvas, restrained green controls, a persistent collection sidebar, plain labeled forms, and visible save/publish states. Preserve factual copy and content.
